//
//  ViewController.swift
//  DataList
//
//  Created by Nandeesh EB on 12/8/20.
//  Copyright © 2020 Nandeesh EB. All rights reserved.
//

import UIKit
import Alamofire

class ListViewController: UITableViewController
{
    var resultList = [Result]()

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.fetchData()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.resultList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        var cell : PersonTableViewCell? = tableView.dequeueReusableCell(withIdentifier: "PersonCell") as? PersonTableViewCell
        
        if (cell == nil) {
            cell = UITableViewCell(style: UITableViewCell.CellStyle.value1, reuseIdentifier: "PersonCell") as? PersonTableViewCell
        }
        
        cell!.nameLabel.text = "\(self.resultList[indexPath.row].name.first)  " +  "\(self.resultList[indexPath.row].name.last)"
        //cell!.thumbImageView.setImageWithUrl(url: self.resultList[indexPath.row].picture.thumbnail, placeHolderImage: "PlaceHolderImage")
        
        let placeholderImage = UIImage(named: "PlaceHolderImage")!
        cell!.thumbImageView.image = placeholderImage
        
        let url = URL(string: self.resultList[indexPath.row].picture.thumbnail)!
        
        AF.request(url, method: .get).responseData { response in
            guard let image = UIImage.init(data: (response.value ?? nil)!)  else { return }
            
            cell?.thumbImageView.image = image
        }
        return cell!
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // On choosing the cell, we can send the particular Person name and other things to FIREBASE
        if let indexPath = self.tableView.indexPathForSelectedRow {
            guard let destinationVC = segue.destination as? DetailViewController else {return}
            destinationVC.selectedPerson = resultList[indexPath.row]
        }
    }
    
    func fetchData(){
        AF.request("https://randomuser.me/api/?results=10", method: .get).responseDecodable(of: PeopleList.self) {response in

            if let results = response.value?.results
            {
                self.resultList = results
                
                if self.resultList.count > 0
                {
                    // Also, we can save the data on local here by using SQLITE/COREDATA
                    self.tableView.reloadData()
                }
            }
            else
            {
                print("Could not fetch the data")
            }
        }
    }
}
