//
//  DetailViewController.swift
//  DataList
//
//  Created by Nandeesh EB on 12/8/20.
//  Copyright © 2020 Nandeesh EB. All rights reserved.
//

import UIKit
import Alamofire

class DetailViewController: UIViewController
{
    @IBOutlet weak var thumbImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    
    var selectedPerson:Result?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool)
    {
        super.viewDidAppear(animated)
        
        let placeholderImage = UIImage(named: "PlaceHolderImage")!
        self.thumbImageView.image = placeholderImage
        
        let url = URL(string: self.selectedPerson?.picture.thumbnail ?? "")!
        
        AF.request(url, method: .get).responseData { response in
            guard let image = UIImage.init(data: (response.value ?? nil)!)  else { return }
            
            self.thumbImageView.image = image
        }
        
        self.nameLabel.text = "\(self.selectedPerson?.name.first ?? "")  " + "\(self.selectedPerson?.name.last ?? "")"
        self.cityLabel.text = "City: " + (self.selectedPerson?.location.city ?? "Missing")
    }
}
